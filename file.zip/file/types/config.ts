export interface FeatureFlag {
  key: string;
  enabled: boolean;
  conditions: Record<string, unknown>;
  description: string;
}

export interface ConfigSetting {
  key: string;
  value: string;
  label: string | null;
  content_type: string | null;
  tags: Record<string, string>;
}

export interface MessageBarConfig {
  title: string;
  description: string;
  intent: "success" | "warning" | "error" | "info";
}

export interface AppConfig {
  feature_flags: FeatureFlag[];
  settings: ConfigSetting[];
}

export interface ConfigContextType {
  config: AppConfig | null;
  loading: boolean;
  getFeatureFlag: (key: string) => boolean;
  getSetting: (key: string) => string | null;
  getMessageBarConfig: () => MessageBarConfig | null;
}
