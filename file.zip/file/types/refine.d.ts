import type en from "@/locales/en.json";

type TranslationKeys = keyof typeof en;

declare module "@refinedev/core" {
  interface UseTranslateReturnType {
    (key: TranslationKeys, options?: Record<string, unknown>, defaultMessage?: string): string;
  }
}
