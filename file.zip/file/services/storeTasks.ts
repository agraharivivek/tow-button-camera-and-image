"use client";

import { useMemo } from "react";
import { useList } from "@refinedev/core";
import type { AnyTask, Campaign, QuestionnaireTask, ResolvedTask, Store, UpcRef } from "@/lib/strapiTypes";

const TASK_DEFINITIONS_POPULATE = {
  on: {
    "tasks.questionnaire-task": { populate: { questions: { populate: "*" } } },
    "tasks.action-task": { populate: "*" },
    "tasks.photo-task": { populate: "*" },
    "tasks.count-task": { populate: "*" },
    "tasks.note-task": { populate: "*" },
  },
};

const CAMPAIGN_POPULATE = {
  stores: true,
  regions: true,
  territories: true,
  retailers: true,
  banners: true,
  storeSegments: { populate: { tags: true } },
  taskDefinitions: TASK_DEFINITIONS_POPULATE,
};

function uidFor(sourceId: number, task: AnyTask): string {
  return `campaign:${sourceId}:${task.__component}:${task.id}`;
}

function matchesCampaign(c: Campaign, store: Store): boolean {
  const target = c.target;

  if (target === "store") {
    return (c.stores ?? []).some((s) => s.id === store.id);
  }
  if (target === "region") {
    const regionId = store.territory?.region?.id;
    return regionId != null && (c.regions ?? []).some((r) => r.id === regionId);
  }
  if (target === "territory") {
    return (c.territories ?? []).some((t) => t.id === store.territory?.id);
  }
  if (target === "retailer") {
    return (c.retailers ?? []).some((r) => r.id === store.banner?.retailer?.id);
  }
  if (target === "banner") {
    return (c.banners ?? []).some((b) => b.id === store.banner?.id);
  }
  if (target === "store_segment") {
    return (c.storeSegments ?? []).some((seg) => {
      if (seg.segmentType === "static") {
        return store.storeNumber != null &&
          (seg.storeNumbers ?? []).includes(store.storeNumber);
      }
      // dynamic: store must have ALL tags from the segment
      const segTagIds = (seg.tags ?? []).map((t) => t.id);
      if (segTagIds.length === 0) return false;
      const storeTagIds = new Set((store as Store & { tags?: { id: number }[] }).tags?.map((t) => t.id) ?? []);
      return segTagIds.every((id) => storeTagIds.has(id));
    });
  }

  // legacy / fallback
  const byStore = (c.stores ?? []).some((s) => s.id === store.id);
  const regionId = store.territory?.region?.id;
  const byRegion = regionId != null && (c.regions ?? []).some((r) => r.id === regionId);
  return byStore || byRegion;
}

/**
 * When a campaign targets store segments, collect UPC codes from any segment that
 * has a storeUpcMap entry for this store. Returns null when UPC expansion doesn't apply.
 */
function resolveUpcTargets(c: Campaign, store: Store): UpcRef[] | null {
  if (c.target !== "store_segment") return null;
  const storeNum = store.storeNumber;
  if (!storeNum) return null;

  const codes: string[] = [];
  for (const seg of c.storeSegments ?? []) {
    const segCodes = seg.storeUpcMap?.[storeNum] ?? [];
    codes.push(...segCodes);
  }
  const unique = [...new Set(codes)];
  return unique.length > 0 ? unique.map((code) => ({ code })) : null;
}

export function useStoreTasks(store?: Store | null): {
  tasks: ResolvedTask[];
  isLoading: boolean;
} {
  const { result: campResult, query: campQuery } = useList<Campaign>({
    resource: "campaigns",
    pagination: { mode: "off" },
    meta: { populate: CAMPAIGN_POPULATE },
    queryOptions: { enabled: !!store },
  });

  // Collect all UPC codes that will need name resolution
  const upcCodes = useMemo(() => {
    if (!store?.storeNumber) return [];
    const camps = (campResult?.data ?? []) as Campaign[];
    const codes = new Set<string>();
    for (const c of camps) {
      if (c.target !== "store_segment") continue;
      for (const seg of c.storeSegments ?? []) {
        for (const code of (seg.storeUpcMap?.[store.storeNumber] ?? [])) {
          codes.add(code);
        }
      }
    }
    return [...codes];
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [campResult?.data, store?.storeNumber]);

  const { result: upcResult } = useList<{ id: number; code?: string; name?: string }>({
    resource: "upcs",
    pagination: { mode: "off" },
    filters: [{ field: "code", operator: "in", value: upcCodes }],
    queryOptions: { enabled: upcCodes.length > 0 },
  });

  const upcNameByCode = useMemo(() => {
    const map: Record<string, string> = {};
    for (const u of upcResult?.data ?? []) {
      if (u.code && u.name) map[u.code] = u.name;
    }
    return map;
  }, [upcResult?.data]);

  const tasks: ResolvedTask[] = [];

  if (store) {
    const camps = (campResult?.data ?? []) as Campaign[];
    for (const c of camps) {
      if (!matchesCampaign(c, store)) continue;

      const upcTargets = resolveUpcTargets(c, store);

      for (const task of c.taskDefinitions ?? []) {
        const shouldExpand =
          task.__component === "tasks.questionnaire-task" &&
          (task as QuestionnaireTask).repeatPerUpc &&
          upcTargets !== null;

        if (shouldExpand) {
          for (const upc of upcTargets!) {
            tasks.push({
              task,
              uid: `${uidFor(c.id, task)}:upc:${upc.code}`,
              sourceType: "campaign",
              sourceId: c.id,
              sourceName: c.name ?? "Campaign",
              upc: { code: upc.code, name: upcNameByCode[upc.code] },
            });
          }
        } else {
          tasks.push({
            task,
            uid: uidFor(c.id, task),
            sourceType: "campaign",
            sourceId: c.id,
            sourceName: c.name ?? "Campaign",
          });
        }
      }
    }
  }

  return { tasks, isLoading: campQuery.isLoading };
}
