"use client";

import type { AuthProvider } from "@refinedev/core";
import { apiClient, setStoredJwt, clearStoredJwt, getStoredJwt } from "@/services/apiClient";
import { userInfoSchema } from "@/validation/userInfoSchema";

type StrapiLoginResponse = {
  jwt: string;
  user: { id: number; username: string; email: string };
};

const ME_POPULATE = "?populate[role]=true&populate[territory]=true";

/**
 * Refine AuthProvider backed by Strapi users-permissions local auth.
 * login -> POST /api/auth/local, JWT persisted in localStorage (see apiClient).
 */
export const authProvider: AuthProvider = {
  login: async ({ identifier, email, password }) => {
    try {
      const res = await apiClient.post<StrapiLoginResponse>("/auth/local", {
        identifier: identifier ?? email,
        password,
      });
      setStoredJwt(res.jwt);
      return { success: true, redirectTo: "/today" };
    } catch (error: unknown) {
      const message =
        (error as { response?: { data?: { error?: { message?: string } } } })?.response?.data
          ?.error?.message || "Invalid credentials";
      return {
        success: false,
        error: { name: "LoginError", message },
      };
    }
  },

  logout: async () => {
    clearStoredJwt();
    return { success: true, redirectTo: "/login" };
  },

  check: async () => {
    if (getStoredJwt()) return { authenticated: true };
    return { authenticated: false, redirectTo: "/login" };
  },

  getIdentity: async () => {
    if (!getStoredJwt()) return null;
    try {
      const data = await apiClient.get<unknown>(`/users/me${ME_POPULATE}`);
      const parsed = userInfoSchema.safeParse(data);
      return parsed.success ? parsed.data : null;
    } catch {
      return null;
    }
  },

  getPermissions: async () => {
    if (!getStoredJwt()) return null;
    try {
      const data = await apiClient.get<{ role?: { name?: string } }>(`/users/me${ME_POPULATE}`);
      return data?.role?.name ?? null;
    } catch {
      return null;
    }
  },

  onError: async (error) => {
    const status = (error as { statusCode?: number; response?: { status?: number } })?.statusCode ??
      (error as { response?: { status?: number } })?.response?.status;
    if (status === 401 || status === 403) {
      clearStoredJwt();
      return { logout: true, redirectTo: "/login" };
    }
    return {};
  },
};
