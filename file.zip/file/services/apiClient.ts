import axios, { AxiosInstance, InternalAxiosRequestConfig } from "axios";

/**
 * Base URL of the Strapi backend (no trailing slash), e.g. http://localhost:1337
 * Set NEXT_PUBLIC_STRAPI_URL in .env. Falls back to localhost for local dev.
 */
export const STRAPI_URL = (
  process.env.NEXT_PUBLIC_STRAPI_URL ||
  process.env.NEXT_PUBLIC_API_URL ||
  "http://localhost:1337"
).replace(/\/$/, "");

export const API_BASE_URL = `${STRAPI_URL}/api`;

const JWT_STORAGE_KEY = "merch.jwt";

export function getStoredJwt(): string | null {
  if (typeof window === "undefined") return null;
  return window.localStorage.getItem(JWT_STORAGE_KEY);
}

export function setStoredJwt(jwt: string): void {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(JWT_STORAGE_KEY, jwt);
}

export function clearStoredJwt(): void {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(JWT_STORAGE_KEY);
}

/** Build an absolute URL to a media/upload file returned by Strapi (which may be relative). */
export function mediaUrl(url?: string | null): string | undefined {
  if (!url) return undefined;
  return url.startsWith("http") ? url : `${STRAPI_URL}${url}`;
}

class ApiClient {
  private readonly client: AxiosInstance;

  constructor() {
    this.client = axios.create({
      baseURL: API_BASE_URL,
      headers: { "Content-Type": "application/json" },
    });
    this.setupInterceptors();
  }

  private setupInterceptors(): void {
    this.client.interceptors.request.use(
      (config: InternalAxiosRequestConfig) => {
        const token = getStoredJwt();
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
      },
      (error) => Promise.reject(error)
    );
  }

  get instance(): AxiosInstance {
    return this.client;
  }

  async get<T>(url: string): Promise<T> {
    const response = await this.client.get<T>(url);
    return response.data;
  }

  async rawGet<T>(url: string) {
    return this.client.get<T>(url);
  }

  async post<T>(url: string, data?: unknown): Promise<T> {
    const response = await this.client.post<T>(url, data);
    return response.data;
  }

  async put<T>(url: string, data?: unknown): Promise<T> {
    const response = await this.client.put<T>(url, data);
    return response.data;
  }

  async delete<T>(url: string): Promise<T> {
    const response = await this.client.delete<T>(url);
    return response.data;
  }

  /** Upload files to Strapi's /api/upload endpoint. Returns the created media records. */
  async upload<T = unknown>(files: File[]): Promise<T> {
    const form = new FormData();
    files.forEach((f) => form.append("files", f));
    // Do NOT set Content-Type manually — the browser must set it with the multipart boundary.
    // Explicitly delete the default application/json so axios doesn't override it.
    const response = await this.client.post<T>("/upload", form, {
      headers: { "Content-Type": undefined },
    });
    return response.data;
  }
}

export const apiClient = new ApiClient();
