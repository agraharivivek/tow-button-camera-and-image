"use client";

import type { DataProvider } from "@refinedev/core";
import { apiClient, API_BASE_URL } from "@/services/apiClient";

type CrudFilter = {
  field: string;
  operator: string;
  value: unknown;
};

type CrudSort = {
  field: string;
  order: "asc" | "desc";
};

/** Map Refine filter operators to Strapi 5 filter operators. */
const OPERATOR_MAP: Record<string, string> = {
  eq: "$eq",
  ne: "$ne",
  lt: "$lt",
  gt: "$gt",
  lte: "$lte",
  gte: "$gte",
  contains: "$containsi",
  containss: "$contains",
  null: "$null",
  nnull: "$notNull",
  in: "$in",
  startswith: "$startsWithi",
  endswith: "$endsWithi",
};

/**
 * Append a `meta.populate`/`meta.fields`/`meta.filters` into URLSearchParams using
 * Strapi 5's bracket query syntax. We accept already-formed nested objects for
 * populate so callers can deep-populate routes/visits.
 */
function appendNested(search: URLSearchParams, key: string, value: unknown): void {
  if (value === undefined || value === null) return;
  if (Array.isArray(value)) {
    value.forEach((v, i) => appendNested(search, `${key}[${i}]`, v));
  } else if (typeof value === "object") {
    Object.entries(value as Record<string, unknown>).forEach(([k, v]) =>
      appendNested(search, `${key}[${k}]`, v)
    );
  } else {
    search.append(key, String(value));
  }
}

function buildListQuery(params: {
  pagination?: { currentPage?: number; pageSize?: number; mode?: string };
  filters?: CrudFilter[];
  sorters?: CrudSort[];
  meta?: Record<string, unknown>;
}): string {
  const search = new URLSearchParams();
  const { pagination, filters, sorters, meta } = params;

  if (pagination?.mode !== "off") {
    search.append("pagination[page]", String(pagination?.currentPage ?? 1));
    search.append("pagination[pageSize]", String(pagination?.pageSize ?? 25));
  } else {
    search.append("pagination[pageSize]", "100");
  }

  filters?.forEach((f) => {
    if (!f.field) return;
    const op = OPERATOR_MAP[f.operator] ?? "$eq";
    // supports dotted field paths e.g. "user.id" -> filters[user][id][$eq]
    const path = f.field.split(".").map((seg) => `[${seg}]`).join("");
    appendNested(search, `filters${path}[${op}]`, f.value);
  });

  sorters?.forEach((s, i) => {
    search.append(`sort[${i}]`, `${s.field}:${s.order}`);
  });

  // meta.populate can be a string[], "*", or a nested object (Strapi deep populate)
  if (meta?.populate !== undefined) {
    appendNested(search, "populate", meta.populate);
  }
  if (meta?.fields !== undefined) {
    appendNested(search, "fields", meta.fields);
  }

  const qs = search.toString();
  return qs ? `?${qs}` : "";
}

function buildItemQuery(meta?: Record<string, unknown>): string {
  const search = new URLSearchParams();
  if (meta?.populate !== undefined) appendNested(search, "populate", meta.populate);
  if (meta?.fields !== undefined) appendNested(search, "fields", meta.fields);
  const qs = search.toString();
  return qs ? `?${qs}` : "";
}

type StrapiListResponse = {
  data: unknown[];
  meta?: { pagination?: { total?: number } };
};
type StrapiItemResponse = { data: unknown };

/**
 * Refine dataProvider for Strapi 5 REST.
 * - Strapi 5 returns a flattened `{ data, meta }` envelope (documentId, no v4 `attributes`).
 * - Pagination via pagination[page]/[pageSize]; filters[field][$op]; sort[i]=field:order.
 * - Deep populate / field selection via meta.populate / meta.fields.
 */
export const refineDataProvider: DataProvider = {
  getApiUrl: () => API_BASE_URL,

  getList: async ({ resource, pagination, filters, sorters, meta }) => {
    const url = `/${resource}${buildListQuery({
      pagination: pagination as never,
      filters: filters as CrudFilter[] | undefined,
      sorters: sorters as CrudSort[] | undefined,
      meta: meta as Record<string, unknown> | undefined,
    })}`;
    const body = await apiClient.get<StrapiListResponse>(url);
    return {
      data: (body.data ?? []) as never,
      total: body.meta?.pagination?.total ?? body.data?.length ?? 0,
    };
  },

  getOne: async ({ resource, id, meta }) => {
    const body = await apiClient.get<StrapiItemResponse>(
      `/${resource}/${id}${buildItemQuery(meta as Record<string, unknown> | undefined)}`
    );
    return { data: body.data as never };
  },

  create: async ({ resource, variables, meta }) => {
    const body = await apiClient.post<StrapiItemResponse>(
      `/${resource}${buildItemQuery(meta as Record<string, unknown> | undefined)}`,
      { data: variables }
    );
    return { data: body.data as never };
  },

  update: async ({ resource, id, variables, meta }) => {
    const body = await apiClient.put<StrapiItemResponse>(
      `/${resource}/${id}${buildItemQuery(meta as Record<string, unknown> | undefined)}`,
      { data: variables }
    );
    return { data: body.data as never };
  },

  deleteOne: async ({ resource, id }) => {
    const body = await apiClient.delete<StrapiItemResponse>(`/${resource}/${id}`);
    return { data: body.data as never };
  },

  getMany: async ({ resource, ids, meta }) => {
    // Strapi filter[id][$in]
    const search = new URLSearchParams();
    ids.forEach((id, i) => search.append(`filters[id][$in][${i}]`, String(id)));
    if ((meta as Record<string, unknown>)?.populate !== undefined) {
      appendNested(search, "populate", (meta as Record<string, unknown>).populate);
    }
    const body = await apiClient.get<StrapiListResponse>(`/${resource}?${search.toString()}`);
    return { data: (body.data ?? []) as never };
  },

  custom: async ({ url, method, payload }) => {
    const fullUrl = url.startsWith("http") ? url : `/${url.replace(/^\//, "")}`;
    const m = (method ?? "get").toLowerCase();
    if (m === "post") return { data: await apiClient.post(fullUrl, payload) } as never;
    if (m === "put") return { data: await apiClient.put(fullUrl, payload) } as never;
    if (m === "delete") return { data: await apiClient.delete(fullUrl) } as never;
    return { data: await apiClient.get(fullUrl) } as never;
  },
};
