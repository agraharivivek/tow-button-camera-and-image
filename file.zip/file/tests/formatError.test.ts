import { describe, expect, it } from "vitest";
import { formatError } from "../utils/formatError";

describe("formatError", () => {
  it("formats an Error instance", () => {
    const error = new Error("Test error");
    const formatted = formatError(error);

    expect(formatted).toHaveProperty("name", "Error");
    expect(formatted).toHaveProperty("message", "Test error");
    expect(formatted).toHaveProperty("stack");
  });

  it("formats a custom Error instance", () => {
    class CustomError extends Error {
      constructor(message: string) {
        super(message);
        this.name = "CustomError";
      }
    }

    const error = new CustomError("Custom error message");
    const formatted = formatError(error);

    expect(formatted).toHaveProperty("name", "CustomError");
    expect(formatted).toHaveProperty("message", "Custom error message");
  });

  it("formats an object error", () => {
    const error = { code: "ERR_001", details: "Something went wrong" };
    const formatted = formatError(error);

    expect(formatted).toEqual({ code: "ERR_001", details: "Something went wrong" });
  });

  it("formats a string error", () => {
    const formatted = formatError("Simple error message");

    expect(formatted).toEqual({ message: "Simple error message" });
  });

  it("formats a number error", () => {
    const formatted = formatError(404);

    expect(formatted).toEqual({ message: "404" });
  });

  it("formats null error", () => {
    const formatted = formatError(null);

    expect(formatted).toEqual({ message: "null" });
  });
});
