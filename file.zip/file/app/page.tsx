"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useIsAuthenticated } from "@refinedev/core";
import { AppLoader } from "@/components/AppLoader";

export default function Home() {
  const router = useRouter();
  const { data, isLoading } = useIsAuthenticated();

  useEffect(() => {
    if (isLoading) return;
    router.replace(data?.authenticated ? "/today" : "/login");
  }, [isLoading, data, router]);

  return <AppLoader />;
}
