"use client";

import { useMemo, useState } from "react";
import { useList } from "@refinedev/core";
import { useUser } from "@/components/AuthProvider";
import { todayWeekday, titleCase } from "@/lib/day";
import {
  type Route,
  type RouteStop,
  type Store,
  type Campaign,
  type AnyTask,
  taskTitle,
  taskTypeLabel,
} from "@/lib/strapiTypes";

const TASK_DEFS_POPULATE = {
  on: {
    "tasks.questionnaire-task": { populate: { questions: { populate: "*" } } },
    "tasks.action-task": { populate: "*" },
    "tasks.photo-task": { populate: "*" },
    "tasks.count-task": { populate: "*" },
    "tasks.note-task": { populate: "*" },
  },
};

interface AggTask {
  task: AnyTask;
  uid: string;
  source: string;
  stores: string[];
}

export default function TasksPage() {
  const { userInfo } = useUser();
  const userId = userInfo?.id;
  const weekday = todayWeekday();
  const [filter, setFilter] = useState("All");

  const { result: routeResult } = useList<Route>({
    resource: "routes",
    filters: [{ field: "user.id", operator: "eq", value: userId }],
    pagination: { mode: "off" },
    meta: {
      populate: {
        [weekday]: {
          populate: { store: { populate: { territory: { populate: { region: true } } } } },
        },
      },
    },
    queryOptions: { enabled: !!userId },
  });

  const { result: campResult, query: campQuery } = useList<Campaign>({
    resource: "campaigns",
    pagination: { mode: "off" },
    meta: { populate: { stores: true, regions: true, taskDefinitions: TASK_DEFS_POPULATE } },
  });

  const aggregated = useMemo<AggTask[]>(() => {
    const route = (routeResult?.data ?? [])[0] as Route | undefined;
    const stops: RouteStop[] = (route?.[weekday] ?? []).filter((s) => s.store);
    const stores = stops.map((s) => s.store as Store);
    const storeIds = new Set(stores.map((s) => s.id));
    const regionIds = new Set(
      stores.map((s) => s.territory?.region?.id).filter((x): x is number => x != null)
    );

    const byUid = new Map<string, AggTask>();
    const add = (task: AnyTask, source: string, sourceId: number, sourceType: string, storeName: string) => {
      const uid = `${sourceType}:${sourceId}:${task.__component}:${task.id}`;
      const existing = byUid.get(uid);
      if (existing) {
        if (!existing.stores.includes(storeName)) existing.stores.push(storeName);
      } else {
        byUid.set(uid, { task, uid, source, stores: [storeName] });
      }
    };

    for (const c of (campResult?.data ?? []) as Campaign[]) {
      for (const s of stores) {
        const byStore = (c.stores ?? []).some((x) => x.id === s.id);
        const byRegion = s.territory?.region?.id != null && (c.regions ?? []).some((r) => r.id === s.territory!.region!.id);
        if (byStore || byRegion) {
          for (const t of c.taskDefinitions ?? []) add(t, c.name ?? "Campaign", c.id, "camp", s.name);
        }
      }
    }
    void storeIds;
    void regionIds;
    return Array.from(byUid.values());
  }, [routeResult, campResult, weekday]);

  const types = useMemo(() => {
    const present = new Set(aggregated.map((a) => taskTypeLabel(a.task)));
    return ["All", ...Array.from(present)];
  }, [aggregated]);

  const visible = aggregated.filter(
    (a) => filter === "All" || taskTypeLabel(a.task) === filter
  );

  const loading = campQuery.isLoading;

  return (
    <>
      <h1 className="merch-page-title">Tasks</h1>
      <div className="merch-page-sub">
        {aggregated.length} task{aggregated.length === 1 ? "" : "s"} across today’s route
      </div>

      <div className="chips">
        {types.map((t) => (
          <button
            key={t}
            className={`chip ${filter === t ? "active" : ""}`}
            onClick={() => setFilter(t)}
          >
            {titleCase(t)}
          </button>
        ))}
      </div>

      {loading && <div className="center-pad">Loading tasks…</div>}
      {!loading && visible.length === 0 && <div className="center-pad">No tasks for today.</div>}

      {visible.map((a) => (
        <div key={a.uid} className="merch-card task-card">
          <div className="task-head">
            <div>
              <div className="task-title">{taskTitle(a.task)}</div>
            </div>
            {a.task.priority && <span className={`badge badge--${a.task.priority}`}>{a.task.priority}</span>}
          </div>
          <div className="task-instructions">
            {a.source} · {a.stores.join(", ")}
          </div>
        </div>
      ))}
    </>
  );
}
