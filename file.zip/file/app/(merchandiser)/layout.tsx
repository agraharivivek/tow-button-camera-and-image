"use client";

import "./merchandiser.scss";
import AuthGuard from "@/components/AuthGuard";
import { AppHeader } from "@/components/merch/AppHeader";
import { BottomTabBar } from "@/components/merch/BottomTabBar";

export default function MerchandiserLayout({
  children,
}: Readonly<{ children: React.ReactNode }>) {
  return (
    <AuthGuard>
      <div className="merch-shell">
        <AppHeader />
        <main className="merch-main">{children}</main>
        <BottomTabBar />
      </div>
    </AuthGuard>
  );
}
