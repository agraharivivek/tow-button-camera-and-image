"use client";

import Link from "next/link";
import { useList } from "@refinedev/core";
import { useUser } from "@/components/AuthProvider";
import { PriorityBadge } from "@/components/merch/PriorityBadge";
import { todayWeekday, weekBounds } from "@/lib/day";
import { routePotential, storeLostSales, legMiles, arrivalTime } from "@/lib/demoMetrics";
import type { Route, RouteStop, StoreVisit, Store } from "@/lib/strapiTypes";
import {
  CalendarLtr24Regular,
  CheckmarkCircle24Regular,
  Target24Regular,
} from "@fluentui/react-icons";

export default function TodayPage() {
  const { userInfo } = useUser();
  const userId = userInfo?.id;
  const weekday = todayWeekday();
  const { start: weekStart, end: weekEnd } = weekBounds();

  const { result: routeResult, query: routeQuery } = useList<Route>({
    resource: "routes",
    filters: [{ field: "user.id", operator: "eq", value: userId }],
    pagination: { mode: "off" },
    meta: { populate: { [weekday]: { populate: { store: true } } } },
    queryOptions: { enabled: !!userId },
  });

  const { result: visitsResult } = useList<StoreVisit & { store?: Store }>({
    resource: "store-visits",
    filters: [
      { field: "user.id", operator: "eq", value: userId },
      { field: "date", operator: "gte", value: weekStart },
      { field: "date", operator: "lte", value: weekEnd },
    ],
    pagination: { mode: "off" },
    meta: { populate: { store: true } },
    queryOptions: { enabled: !!userId },
  });

  const route = (routeResult?.data ?? [])[0] as Route | undefined;
  const stops: RouteStop[] = (route?.[weekday] ?? []).filter((s) => s.store);

  // map storeId -> visit status; a completed visit always wins over a duplicate
  // in_progress/pending one for the same store.
  const visitByStore = new Map<number, string>();
  for (const v of (visitsResult?.data ?? []) as (StoreVisit & { store?: Store })[]) {
    const sid = v.store?.id;
    if (!sid) continue;
    const prev = visitByStore.get(sid);
    if (v.status === "completed" || prev !== "completed") {
      visitByStore.set(sid, v.status ?? "pending");
    }
  }

  const total = stops.length;
  const done = stops.filter((s) => visitByStore.get(s.store!.id) === "completed").length;
  const remaining = total - done;
  const pct = total ? Math.round((done / total) * 100) : 0;
  const potential = routePotential(stops.map((s) => s.store!.id));

  if (routeQuery.isLoading) {
    return <div className="center-pad">Loading today’s route…</div>;
  }

  return (
    <>
      <div className="summary-row">
        <div className="summary-cell">
          <CalendarLtr24Regular className="ic" style={{ color: "var(--kh-navy)" }} />
          <div className="big">{total}</div>
          <div className="lbl">Stops</div>
        </div>
        <div className="summary-cell">
          <CheckmarkCircle24Regular className="ic" style={{ color: "var(--kh-green)" }} />
          <div className="big">{done}</div>
          <div className="lbl">Done</div>
        </div>
        <div className="summary-cell">
          <Target24Regular className="ic" style={{ color: "#e0a500" }} />
          <div className="big">{remaining}</div>
          <div className="lbl">Remaining</div>
        </div>
      </div>

      <div className="merch-card progress-card">
        <div className="row">
          <span>Route progress</span>
          <span className="accent">
            {done}/{total} stops
          </span>
        </div>
        <div className="bar">
          <div className="fill" style={{ width: `${pct}%` }} />
        </div>
        <div className="miles">🚩 {potential.miles} mi total</div>
      </div>

      <div className="merch-card progress-card">
        <div className="row">
          <span>💲 Route potential</span>
          <span className="accent">${potential.potential.toLocaleString()}</span>
        </div>
        <div className="miles">🏆 +{potential.points} pts to rep</div>
      </div>

      <h2 className="merch-page-title" style={{ fontSize: 20, marginTop: 18 }}>
        Today’s route
      </h2>

      {total === 0 && (
        <div className="center-pad">No stops scheduled for {weekday}.</div>
      )}

      {stops.map((stop, i) => {
        const store = stop.store as Store;
        const status = visitByStore.get(store.id) ?? "pending";
        return (
          <Link key={stop.id} href={`/visit?store=${store.id}`} className="merch-card stop-card">
            <div className="top">
              <span className="idx">{i + 1}</span>
              <div style={{ flex: 1 }}>
                <div className="name">{store.name}</div>
                {store.storeNumber && <div className="sub">Store {store.storeNumber}</div>}
              </div>
              <span className={`badge badge--${status === "completed" ? "done" : "status"}`}>
                {status === "completed" ? "DONE" : "PENDING"}
              </span>
            </div>
            <div className="addr">
              {[store.address, store.city, store.zip].filter(Boolean).join(", ")}
            </div>
            <div className="meta">
              <PriorityBadge priority={store.priority} />
              <span className="pill pill--lost">
                ${storeLostSales(store.id).toLocaleString()} lost sales
              </span>
            </div>
            {stop.notes && <div className="sub" style={{ marginTop: 8 }}>{stop.notes}</div>}
            <div className="leg">
              Arrive {arrivalTime(i)} · ~{legMiles(i)} mi leg
            </div>
          </Link>
        );
      })}
    </>
  );
}
