"use client";

export default function ReportsPage() {
  return (
    <>
      <h1 className="merch-page-title">Reports</h1>
      <div className="merch-page-sub">Your execution performance</div>
      <div className="merch-card center-pad">
        📊 Reports & analytics coming soon.
      </div>
    </>
  );
}
