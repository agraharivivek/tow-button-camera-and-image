"use client";

import { Suspense, useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { useList } from "@refinedev/core";
import { useUser } from "@/components/AuthProvider";
import { AppLoader } from "@/components/AppLoader";
import { PriorityBadge } from "@/components/merch/PriorityBadge";
import { TaskRenderer, type TaskCompletePayload } from "@/components/tasks/TaskRenderer";
import { useStoreTasks } from "@/services/storeTasks";
import { apiClient } from "@/services/apiClient";
import { isoDate, weekBounds } from "@/lib/day";
import {
  type Store,
  type ResolvedTask,
  taskTitle,
  taskTypeLabel,
} from "@/lib/strapiTypes";

interface VisitRecord { id: number; documentId: string }
interface ResponseRecord { documentId: string; status: string }

function VisitInner() {
  const router = useRouter();
  const params = useSearchParams();
  const storeId = Number(params.get("store"));
  const { userInfo } = useUser();
  const userId = userInfo?.id;

  const { result: storeRes, query: storeQuery } = useList<Store>({
    resource: "stores",
    filters: [{ field: "id", operator: "eq", value: storeId }],
    meta: { populate: { banner: { populate: { retailer: true } }, territory: { populate: { region: true } } } },
    queryOptions: { enabled: !!storeId },
  });
  const store = (storeRes?.data ?? [])[0] as Store | undefined;

  const { tasks, isLoading: tasksLoading } = useStoreTasks(store);

  const [visit, setVisit] = useState<VisitRecord | null>(null);
  const [responses, setResponses] = useState<Record<string, ResponseRecord>>({});
  const [responsesLoaded, setResponsesLoaded] = useState(false);
  const [savingUid, setSavingUid] = useState<string | null>(null);
  const [activeIdx, setActiveIdx] = useState(0);
  const initialJumpRef = useRef(false);
  const ensuringKeyRef = useRef<string | null>(null);
  // questionKey → answerValue — flat map across all completed responses for this store
  const [campaignAnswerHistory, setCampaignAnswerHistory] = useState<Record<string, unknown>>({});
  const historyFetchedRef = useRef<number | null>(null);

  useEffect(() => {
    if (!userId || !storeId) return;
    const today = isoDate();
    const { start: weekStart, end: weekEnd } = weekBounds();
    // Key is week-stable so we don't re-create a visit on every day of the same week
    const key = `${userId}:${storeId}:${weekStart}`;
    if (ensuringKeyRef.current === key) return;
    ensuringKeyRef.current = key;

    (async () => {
      type VisitRow = {
        id: number; documentId: string; status?: string;
        taskResponses?: Array<{ documentId: string; taskUid?: string; status?: string }>;
      };
      try {
        const found = await apiClient.get<{ data: VisitRow[] }>(
          `/store-visits?filters[user][id][$eq]=${userId}&filters[store][id][$eq]=${storeId}&filters[date][$gte]=${weekStart}&filters[date][$lte]=${weekEnd}&sort=id:desc&populate[taskResponses]=true`
        );
        const rows = found.data ?? [];
        let record: VisitRow | undefined =
          rows.find((r) => r.status === "completed") ?? rows[0];
        if (!record) {
          const created = await apiClient.post<{ data: { id: number; documentId: string } }>(
            "/store-visits",
            { data: { user: userId, store: storeId, date: today, status: "in_progress", source: "route" } }
          );
          record = { ...created.data, taskResponses: [] };
        }
        setVisit({ id: record.id, documentId: record.documentId });
        const map: Record<string, ResponseRecord> = {};
        (record.taskResponses ?? []).forEach((r) => {
          if (r.taskUid) map[r.taskUid] = { documentId: r.documentId, status: r.status ?? "pending" };
        });
        setResponses(map);
        setResponsesLoaded(true);
      } catch (e) {
        ensuringKeyRef.current = null;
        console.error("Failed to load/create store visit", e);
      }
    })();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [userId, storeId]);

  // Fetch all store-visits for this store (across all time) and collect completed task responses.
  // Used to power "ask once per campaign" question suppression.
  // Uses a single-level relation filter (store-visit → store) which Strapi 5 reliably supports.
  useEffect(() => {
    if (!storeId || historyFetchedRef.current === storeId) return;
    historyFetchedRef.current = storeId;
    type HistoryVisit = {
      taskResponses?: Array<{ answers?: Record<string, unknown>; status?: string }>;
    };
    apiClient
      .get<{ data: HistoryVisit[] }>(
        `/store-visits?filters[store][id][$eq]=${storeId}&pagination[pageSize]=200&populate[taskResponses]=true`
      )
      .then((body) => {
        // Flat map: questionKey → answer, merged across all completed responses.
        // No campaign/task ID in the key so suppression survives campaign updates.
        const map: Record<string, unknown> = {};
        for (const visit of body.data ?? []) {
          for (const r of visit.taskResponses ?? []) {
            if (r.status === "completed" && r.answers) {
              Object.assign(map, r.answers);
            }
          }
        }
        setCampaignAnswerHistory(map);
      })
      .catch((err) => console.error("Failed to load campaign answer history", err));
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [storeId]);

  // Jump to the first incomplete task once both tasks and responses are loaded
  useEffect(() => {
    if (initialJumpRef.current || !responsesLoaded || tasks.length === 0) return;
    initialJumpRef.current = true;
    const firstIncomplete = tasks.findIndex((t) => responses[t.uid]?.status !== "completed");
    setActiveIdx(firstIncomplete !== -1 ? firstIncomplete : 0);
  }, [responsesLoaded, tasks, responses]);

  const completedUids = useMemo(
    () => new Set(Object.entries(responses).filter(([, r]) => r.status === "completed").map(([uid]) => uid)),
    [responses]
  );
  const total = tasks.length;
  const done = completedUids.size;

  const onComplete = useCallback(
    async (resolved: ResolvedTask, payload: TaskCompletePayload) => {
      if (!visit) return;
      setSavingUid(resolved.uid);
      try {
        let photoIds: number[] = [];
        if (payload.photos?.length) {
          const uploaded = await apiClient.upload<Array<{ id: number }>>(payload.photos);
          photoIds = uploaded.map((u) => u.id);
        }
        const data: Record<string, unknown> = {
          visit: visit.id,
          taskUid: resolved.uid,
          taskType: taskTypeLabel(resolved.task),
          taskTitle: taskTitle(resolved.task),
          status: "completed",
          answers: payload.answers,
        };
        if (photoIds.length) data.photos = photoIds;

        const existing = responses[resolved.uid];
        let savedDocId: string;
        if (existing) {
          const res = await apiClient.put<{ data: { documentId: string } }>(
            `/task-responses/${existing.documentId}`, { data }
          );
          savedDocId = res.data.documentId;
        } else {
          const res = await apiClient.post<{ data: { documentId: string } }>("/task-responses", { data });
          savedDocId = res.data.documentId;
        }

        const nextResponses = {
          ...responses,
          [resolved.uid]: { documentId: savedDocId, status: "completed" },
        };
        setResponses(nextResponses);

        const completedCount = tasks.filter((t) => nextResponses[t.uid]?.status === "completed").length;
        const status = completedCount >= tasks.length && tasks.length > 0 ? "completed" : "in_progress";
        await apiClient.put(`/store-visits/${visit.documentId}`, { data: { status } });

        // Auto-advance to next incomplete task
        const nextIncomplete = tasks.findIndex((t, i) => i > activeIdx && nextResponses[t.uid]?.status !== "completed");
        if (nextIncomplete !== -1) setActiveIdx(nextIncomplete);
        else if (activeIdx < tasks.length - 1) setActiveIdx(activeIdx + 1);
      } catch (e) {
        console.error("Failed to save task response", e);
        alert("Could not save. Check that the Strapi server is running and permissions are set.");
      } finally {
        setSavingUid(null);
      }
    },
    [visit, responses, tasks, activeIdx]
  );

  if (storeQuery.isLoading || !store) return <div className="center-pad">Loading store…</div>;

  const safeIdx = Math.min(activeIdx, Math.max(0, tasks.length - 1));
  const current = tasks[safeIdx];

  return (
    <>
      {/* ── Store header ── */}
      <div className="back-row">
        <button className="back-btn" onClick={() => router.back()} aria-label="Back">←</button>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontWeight: 800, fontSize: 16, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
            {store.name}
          </div>
          <div style={{ fontSize: 12, color: "var(--kh-muted)" }}>
            {[store.address, store.city].filter(Boolean).join(", ")}
          </div>
        </div>
        <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
          <PriorityBadge priority={store.priority} />
          <span className="badge badge--done">{done}/{total}</span>
        </div>
      </div>

      {/* ── Progress bar ── */}
      <div className="visit-progress-strip">
        <div className="visit-progress-bar">
          <div className="visit-progress-fill" style={{ width: `${total ? Math.round((done / total) * 100) : 0}%` }} />
        </div>
      </div>

      {tasksLoading && <div className="center-pad">Loading tasks…</div>}
      {!tasksLoading && total === 0 && <div className="center-pad">No tasks assigned to this store.</div>}

      {/* ── Task stepper nav ── */}
      {total > 0 && (
        <div className="task-step-nav">
          <button
            className="step-arrow"
            onClick={() => setActiveIdx((i) => Math.max(0, i - 1))}
            disabled={safeIdx === 0}
          >
            ‹
          </button>
          <div className="step-dots">
            {tasks.map((t, i) => (
              <button
                key={t.uid}
                className={`step-dot ${i === safeIdx ? "active" : ""} ${completedUids.has(t.uid) ? "done" : ""}`}
                onClick={() => setActiveIdx(i)}
                aria-label={`Task ${i + 1}`}
              />
            ))}
          </div>
          <button
            className="step-arrow"
            onClick={() => setActiveIdx((i) => Math.min(tasks.length - 1, i + 1))}
            disabled={safeIdx === tasks.length - 1}
          >
            ›
          </button>
        </div>
      )}

      {/* ── Current task ── */}
      {current && (
        <div className="task-step-label">
          Task {safeIdx + 1} of {total} · {current.sourceName}
        </div>
      )}
      {current && (
        <TaskRenderer
          key={current.uid}
          resolved={current}
          completed={completedUids.has(current.uid)}
          saving={savingUid === current.uid}
          onComplete={(payload) => onComplete(current, payload)}
          storeId={store.id}
          campaignAnswerHistory={campaignAnswerHistory}
        />
      )}
    </>
  );
}

export default function VisitPage() {
  return (
    <Suspense fallback={<AppLoader />}>
      <VisitInner />
    </Suspense>
  );
}
