"use client";

import { useLogout } from "@refinedev/core";
import { Button } from "@kraftheinz-org/delishdesign-react";
import { useUser } from "@/components/AuthProvider";

export default function ProfilePage() {
  const { userInfo } = useUser();
  const { mutate: logout } = useLogout();

  return (
    <>
      <h1 className="merch-page-title">Profile</h1>
      <div className="merch-card">
        <div className="name" style={{ fontWeight: 800, fontSize: 18 }}>
          {userInfo?.fullName || userInfo?.username}
        </div>
        <div className="muted">{userInfo?.email}</div>
        <div className="muted" style={{ marginTop: 8 }}>
          Territory: {userInfo?.territory?.name ?? "—"}
        </div>
        <div className="muted">Role: {userInfo?.role?.name ?? "—"}</div>
      </div>
      <Button appearance="secondary" size="large" style={{ width: "100%" }} onClick={() => logout()}>
        Sign out
      </Button>
    </>
  );
}
