"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useList } from "@refinedev/core";
import { useUser } from "@/components/AuthProvider";
import { PriorityBadge } from "@/components/merch/PriorityBadge";
import type { Store } from "@/lib/strapiTypes";

export default function StoresPage() {
  const { userInfo } = useUser();
  const territoryId = userInfo?.territory?.id;
  const [search, setSearch] = useState("");
  const [retailer, setRetailer] = useState<string>("All");

  const { result, query } = useList<Store>({
    resource: "stores",
    filters: territoryId
      ? [{ field: "territory.id", operator: "eq", value: territoryId }]
      : [],
    pagination: { mode: "off" },
    sorters: [{ field: "name", order: "asc" }],
    meta: { populate: { banner: { populate: { retailer: true } }, territory: true } },
    queryOptions: { enabled: !!territoryId },
  });

  const stores = useMemo(() => (result?.data ?? []) as Store[], [result]);

  const retailers = useMemo(() => {
    const set = new Set<string>();
    stores.forEach((s) => {
      const name = s.banner?.retailer?.name;
      if (name) set.add(name);
    });
    return ["All", ...Array.from(set)];
  }, [stores]);

  const filtered = stores.filter((s) => {
    const q = search.trim().toLowerCase();
    const matchesSearch =
      !q ||
      s.name.toLowerCase().includes(q) ||
      (s.zip ?? "").toLowerCase().includes(q) ||
      (s.city ?? "").toLowerCase().includes(q);
    const matchesRetailer = retailer === "All" || s.banner?.retailer?.name === retailer;
    return matchesSearch && matchesRetailer;
  });

  return (
    <>
      <h1 className="merch-page-title">Stores</h1>
      <div className="merch-page-sub">
        {stores.length} location{stores.length === 1 ? "" : "s"} in territory
        {userInfo?.territory?.name ? ` · ${userInfo.territory.name}` : ""}
      </div>

      <input
        className="search-input"
        placeholder="Search stores or zip codes…"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      <div className="chips">
        {retailers.map((r) => (
          <button
            key={r}
            className={`chip ${retailer === r ? "active" : ""}`}
            onClick={() => setRetailer(r)}
          >
            {r}
          </button>
        ))}
      </div>

      {query.isLoading && <div className="center-pad">Loading stores…</div>}
      {!query.isLoading && filtered.length === 0 && (
        <div className="center-pad">No stores match.</div>
      )}

      {filtered.map((store) => (
        <div key={store.id} className="merch-card">
          <div className="top" style={{ display: "flex", justifyContent: "space-between" }}>
            <div>
              <div className="name" style={{ fontWeight: 800 }}>
                {store.name}
              </div>
              <div className="sub muted">
                {[store.city, store.zip].filter(Boolean).join(" · ")}
              </div>
            </div>
            <PriorityBadge priority={store.priority} />
          </div>
          <Link href={`/visit?store=${store.id}`} className="btn-primary">
            Open store visit
          </Link>
        </div>
      ))}
    </>
  );
}
