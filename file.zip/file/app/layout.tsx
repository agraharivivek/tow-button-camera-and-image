"use client";
import "@kraftheinz-org/delishdesign-react/segoe.css";
import "@kraftheinz-org/delishdesign-react/tokens.css";
import "./globals.scss";
import { Suspense } from "react";

import { RefineProvider } from "@/components/RefineProvider";
import { I18nProvider } from "@/components/I18nProvider";
import { ThemeProvider } from "@kraftheinz-org/delishdesign-react";

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <meta
          name="viewport"
          content="width=device-width, initial-scale=1, viewport-fit=cover, maximum-scale=1"
        />
      </head>
      <body>
        <Suspense fallback={<div className="center-pad">Loading...</div>}>
          <I18nProvider>
            <ThemeProvider>
              <RefineProvider>{children}</RefineProvider>
            </ThemeProvider>
          </I18nProvider>
        </Suspense>
      </body>
    </html>
  );
}
