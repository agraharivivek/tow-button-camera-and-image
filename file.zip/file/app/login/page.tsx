"use client";

import "../(merchandiser)/merchandiser.scss";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { useLogin, useIsAuthenticated } from "@refinedev/core";
import { Button } from "@kraftheinz-org/delishdesign-react";
import { Wordmark } from "@/components/merch/AppHeader";

export default function LoginPage() {
  const router = useRouter();
  const { mutate: login, isPending } = useLogin();
  const { data: authData } = useIsAuthenticated();

  const [identifier, setIdentifier] = useState("john.smith@test.com");
  const [password, setPassword] = useState("Password1");
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (authData?.authenticated) router.replace("/today");
  }, [authData, router]);

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    login(
      { identifier, password },
      {
        onSuccess: (data) => {
          if (!data.success) {
            setError(data.error?.message ?? "Login failed");
          }
        },
        onError: (err) => setError((err as Error)?.message ?? "Login failed"),
      }
    );
  };

  return (
    <div className="login-wrap">
      <Wordmark className="login-logo" />
      <div className="login-sub">Store Execution</div>

      <form onSubmit={onSubmit}>
        <label htmlFor="identifier">Email or username</label>
        <input
          id="identifier"
          className="search-input"
          style={{ marginBottom: 0 }}
          value={identifier}
          onChange={(e) => setIdentifier(e.target.value)}
          autoCapitalize="none"
          autoCorrect="off"
        />

        <label htmlFor="password">Password</label>
        <input
          id="password"
          type="password"
          className="search-input"
          style={{ marginBottom: 0 }}
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />

        <Button
          appearance="primary"
          size="large"
          type="submit"
          disabled={isPending}
          style={{ width: "100%", marginTop: 20 }}
        >
          {isPending ? "Signing in…" : "Sign in"}
        </Button>

        {error && <div className="login-error">{error}</div>}
      </form>
    </div>
  );
}
