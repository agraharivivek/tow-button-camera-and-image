"use client";

import { useGetIdentity, useIsAuthenticated } from "@refinedev/core";
import type { UserInfo } from "@/validation/userInfoSchema";

/**
 * Thin wrapper over Refine identity hooks (backed by the Strapi authProvider).
 * Must be used inside <Refine>. Kept under this path for backward compatibility
 * with existing imports (rbac, Sidebar).
 */
export function useUser(): { userInfo: UserInfo | null; loading: boolean } {
  const { data, isLoading } = useGetIdentity<UserInfo>();
  return { userInfo: (data as UserInfo) ?? null, loading: isLoading };
}

export function useAuthenticated(): boolean {
  const { data } = useIsAuthenticated();
  return data?.authenticated ?? false;
}

/** No-op provider retained so legacy `import AuthProvider` sites keep compiling. */
export default function AuthProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  return <>{children}</>;
}
