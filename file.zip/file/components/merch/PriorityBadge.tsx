import type { Priority } from "@/lib/strapiTypes";

export function PriorityBadge({ priority }: { priority?: Priority | null }) {
  if (!priority) return null;
  return <span className={`badge badge--${priority}`}>{priority}</span>;
}
