"use client";

import { useUser } from "@/components/AuthProvider";
import { formatLongDate } from "@/lib/day";

export function Wordmark({ className }: { className?: string }) {
  return (
    <span className={className}>
      <span className="k">Kraft</span>
      <span className="h">Heinz</span>
    </span>
  );
}

export function AppHeader() {
  const { userInfo } = useUser();
  const name = userInfo?.fullName || userInfo?.username || "";
  return (
    <header className="merch-header">
      <Wordmark className="merch-logo" />
      <div className="merch-user">
        <div className="name">{name}</div>
        <div className="date">{formatLongDate()}</div>
      </div>
    </header>
  );
}
