"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Home24Regular,
  Building24Regular,
  ClipboardTask24Regular,
  DataBarVertical24Regular,
  Person24Regular,
} from "@fluentui/react-icons";

const TABS = [
  { href: "/today", label: "Today", Icon: Home24Regular },
  { href: "/stores", label: "Stores", Icon: Building24Regular },
  { href: "/tasks", label: "Tasks", Icon: ClipboardTask24Regular },
  { href: "/reports", label: "Reports", Icon: DataBarVertical24Regular },
  { href: "/profile", label: "Profile", Icon: Person24Regular },
];

export function BottomTabBar() {
  const pathname = usePathname();
  return (
    <nav className="merch-tabbar">
      {TABS.map(({ href, label, Icon }) => {
        const active = pathname === href || pathname.startsWith(`${href}/`);
        return (
          <Link key={href} href={href} className={active ? "active" : ""}>
            <Icon />
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
