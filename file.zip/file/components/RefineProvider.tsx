"use client";

import { Refine } from "@refinedev/core";
import routerProvider from "@refinedev/nextjs-router";
import { refineDataProvider } from "@/services/refineDataProvider";
import { authProvider } from "@/services/authProvider";
import { useI18n } from "@/components/I18nProvider";

/**
 * Resource names map 1:1 to Strapi 5 plural API slugs (used as `/${resource}`
 * by the data provider). Merchandiser screens use these via useList/useOne.
 */
const resources = [
  { name: "routes", meta: { label: "Routes" } },
  { name: "stores", meta: { label: "Stores" } },
{ name: "campaigns", meta: { label: "Campaigns" } },
  { name: "store-visits", meta: { label: "Store Visits" } },
  { name: "task-responses", meta: { label: "Task Responses" } },
  { name: "territories", meta: { label: "Territories" } },
  // Reference data (no dedicated screens; used for lookups)
  { name: "products" },
  { name: "upcs" },
  { name: "categories" },
  { name: "brands" },
];

export function RefineProvider({ children }: Readonly<{ children: React.ReactNode }>) {
  const { i18nProvider } = useI18n();

  return (
    <Refine
      dataProvider={refineDataProvider}
      authProvider={authProvider}
      routerProvider={routerProvider}
      resources={resources}
      i18nProvider={i18nProvider}
      options={{
        disableTelemetry: true,
        syncWithLocation: false,
        warnWhenUnsavedChanges: false,
        liveMode: "off",
      }}
    >
      {children}
    </Refine>
  );
}
