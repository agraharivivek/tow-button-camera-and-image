"use client";

import { useEffect, useState } from "react";
import en from "@/locales/en.json";
import es from "@/locales/es.json";

const translations: Record<string, Record<string, string>> = { en, es };
type SupportedLanguage = "en" | "es";

interface BackendStatusProps {
  isHealthy: boolean | null;
}

export function BackendStatus({ isHealthy }: Readonly<BackendStatusProps>) {
  const [language, setLanguage] = useState<SupportedLanguage>("en");

  useEffect(() => {
    const updateLanguage = () => {
      const lang = document.documentElement.lang as SupportedLanguage;
      if (lang in translations) {
        setLanguage(lang);
      }
    };

    updateLanguage();

    const observer = new MutationObserver(updateLanguage);
    observer.observe(document.documentElement, {
      attributes: true,
      attributeFilter: ["lang"],
    });

    return () => observer.disconnect();
  }, []);

  const t = translations[language];

  // Don't render until first health check completes
  if (isHealthy === null) {
    return null;
  }

  return (
    <div className="absolute right-4 top-4 flex items-center gap-2 text-sm">
      <span className={`h-2 w-2 rounded-full ${isHealthy ? "bg-green-500" : "bg-red-500"}`} />
      <span className="text-gray-600">
        {isHealthy ? t["common.backendOnline"] : t["common.backendOffline"]}
      </span>
    </div>
  );
}
