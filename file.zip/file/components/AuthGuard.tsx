"use client";

import { useIsAuthenticated } from "@refinedev/core";
import { useRouter } from "next/navigation";
import { useEffect } from "react";
import { AppLoader } from "@/components/AppLoader";

interface AuthGuardProps {
  children: React.ReactNode;
}

/**
 * Client-side route protection (static-export / Capacitor friendly — no middleware).
 * Redirects unauthenticated users to /login.
 */
export default function AuthGuard({ children }: Readonly<AuthGuardProps>) {
  const { data, isLoading } = useIsAuthenticated();
  const router = useRouter();
  const authenticated = data?.authenticated ?? false;

  useEffect(() => {
    if (!isLoading && !authenticated) {
      router.replace("/login");
    }
  }, [isLoading, authenticated, router]);

  if (isLoading || !authenticated) {
    return <AppLoader />;
  }

  return <>{children}</>;
}
