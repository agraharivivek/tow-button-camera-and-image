"use client";

import { Spinner } from "@fluentui/react-components";
import styles from "./AppLoader.module.scss";

export function AppLoader() {
  return (
    <div className={styles.loaderContainer}>
      <Spinner size="huge" label="Loading..." />
    </div>
  );
}
