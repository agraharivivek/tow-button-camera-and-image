"use client";

import { createContext, useContext, useState, useCallback, useMemo, ReactNode } from "react";
import type { I18nProvider as RefineI18nProvider } from "@refinedev/core";
import en from "@/locales/en.json";
import es from "@/locales/es.json";

const translations: Record<string, Record<string, string>> = { en, es };
export type SupportedLanguage = "en" | "es";

interface I18nContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  i18nProvider: RefineI18nProvider;
}

const I18nContext = createContext<I18nContextType | undefined>(undefined);

export function useI18n() {
  const context = useContext(I18nContext);
  if (!context) {
    throw new Error("useI18n must be used within I18nProvider");
  }
  return context;
}

interface I18nProviderProps {
  children: ReactNode;
}

export function I18nProvider({ children }: Readonly<I18nProviderProps>) {
  const [language, setLanguage] = useState<SupportedLanguage>(() => {
    if (globalThis.window !== undefined) {
      const savedLang = localStorage.getItem("language") as SupportedLanguage;
      if (savedLang && savedLang in translations) {
        document.documentElement.lang = savedLang;
        return savedLang;
      }
    }
    return "en";
  });

  const setLanguageState = useCallback((lang: SupportedLanguage) => {
    setLanguage(lang);
    localStorage.setItem("language", lang);
    document.documentElement.lang = lang;
  }, []);

  const i18nProvider: RefineI18nProvider = useMemo(
    () => ({
      translate: (key: string, options?: Record<string, unknown>, defaultMessage?: string) => {
        const val = translations[language]?.[key];
        if (!val) return defaultMessage ?? key;
        if (!options) return val;
        return val.replaceAll(/\{\{(\w+)\}\}/g, (_, k) => String(options[k] ?? `{{${k}}}`));
      },
      changeLocale: (locale: string) => {
        if (locale in translations) {
          setLanguageState(locale as SupportedLanguage);
        }
        return Promise.resolve();
      },
      getLocale: () => language,
    }),
    [language, setLanguageState]
  );

  const contextValue = useMemo(
    () => ({
      language,
      setLanguage: setLanguageState,
      i18nProvider,
    }),
    [language, setLanguageState, i18nProvider]
  );

  return <I18nContext.Provider value={contextValue}>{children}</I18nContext.Provider>;
}

export default I18nProvider;
