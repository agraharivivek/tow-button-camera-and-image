/** Flatten Strapi "blocks" rich text into a plain string (good enough for display). */
export function blocksToText(blocks: unknown): string {
  if (!Array.isArray(blocks)) return "";
  const walk = (node: unknown): string => {
    if (!node || typeof node !== "object") return "";
    const n = node as { text?: string; children?: unknown[] };
    if (typeof n.text === "string") return n.text;
    if (Array.isArray(n.children)) return n.children.map(walk).join("");
    return "";
  };
  return blocks.map(walk).join("\n").trim();
}
