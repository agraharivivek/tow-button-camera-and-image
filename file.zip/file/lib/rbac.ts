"use client";

import { useUser } from "@/components/AuthProvider";

/**
 * Whether the current Strapi user has an admin-type role.
 * (users-permissions default roles are "Authenticated"/"Public"; treat a role
 * named admin / super admin as elevated.)
 */
export function useIsAdmin(): { isAdmin: boolean; ready: boolean } {
  const { userInfo, loading } = useUser();
  if (loading) return { isAdmin: false, ready: false };
  if (!userInfo) return { isAdmin: false, ready: true };
  const roleName = (userInfo.role?.name || "").toLowerCase();
  return {
    isAdmin: roleName === "admin" || roleName === "super admin",
    ready: true,
  };
}
