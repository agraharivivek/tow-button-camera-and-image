import type { Weekday } from "@/lib/strapiTypes";

const WEEKDAYS: Weekday[] = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

/** Current weekday key (local time), e.g. "monday". */
export function todayWeekday(date: Date = new Date()): Weekday {
  return WEEKDAYS[date.getDay()];
}

/** "Wednesday, April 8, 2026" style label used in the header. */
export function formatLongDate(date: Date = new Date()): string {
  return date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

/** ISO date (YYYY-MM-DD) in local time, used for store-visit `date`. */
export function isoDate(date: Date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

/**
 * Returns the ISO dates for Monday and Sunday of the week containing `date`.
 * Week starts on Monday (ISO 8601).
 */
export function weekBounds(date: Date = new Date()): { start: string; end: string } {
  const d = new Date(date);
  const day = d.getDay(); // 0=Sun … 6=Sat
  const toMonday = day === 0 ? -6 : 1 - day;
  d.setDate(d.getDate() + toMonday);
  const start = isoDate(d);
  d.setDate(d.getDate() + 6);
  const end = isoDate(d);
  return { start, end };
}

export function titleCase(s: string): string {
  return s
    .replace(/[_-]+/g, " ")
    .replace(/\b\w/g, (c) => c.toUpperCase());
}
