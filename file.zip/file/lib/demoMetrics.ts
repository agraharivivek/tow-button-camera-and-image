/**
 * Presentational demo metrics shown in the mockups (lost sales, route potential,
 * mileage, rep points). These have NO backing data in Strapi yet — they are
 * deterministically derived from a store/route id so the UI looks alive.
 * Swap this module for real analytics later.
 */

function hash(n: number): number {
  // simple deterministic pseudo-random in [0,1)
  const x = Math.sin(n * 99.13) * 10000;
  return x - Math.floor(x);
}

export function storeLostSales(storeId: number): number {
  return Math.round((1500 + hash(storeId) * 4000) / 10) * 10;
}

export function storeVoids(storeId: number): number {
  return 8 + Math.floor(hash(storeId + 7) * 24);
}

export interface RoutePotential {
  potential: number;
  points: number;
  miles: number;
}

export function routePotential(stopStoreIds: number[]): RoutePotential {
  const potential = stopStoreIds.reduce((sum, id) => sum + storeLostSales(id) * 2.5, 0);
  const miles = stopStoreIds.length ? 6 + stopStoreIds.length * 9.6 : 0;
  return {
    potential: Math.round(potential / 10) * 10,
    points: stopStoreIds.length + 3,
    miles: Math.round(miles * 10) / 10,
  };
}

export function legMiles(index: number): number {
  return Math.round((4 + hash(index + 3) * 7) * 10) / 10;
}

export function arrivalTime(index: number): string {
  const start = 8 * 60 + 30; // 08:30
  const minutes = start + index * 75;
  const h = Math.floor(minutes / 60) % 24;
  const m = minutes % 60;
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}`;
}
