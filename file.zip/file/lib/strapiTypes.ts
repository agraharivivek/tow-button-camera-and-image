/** Strapi 5 flattened entity shapes used by the merchandiser app. */

export type Priority = "low" | "medium" | "high" | "critical";

export interface Region {
  id: number;
  documentId?: string;
  name?: string;
}

export interface Territory {
  id: number;
  documentId?: string;
  name?: string;
  region?: Region | null;
}

export interface Retailer {
  id: number;
  documentId?: string;
  name?: string;
}

export interface Banner {
  id: number;
  documentId?: string;
  name?: string;
  retailer?: Retailer | null;
}

export interface Store {
  id: number;
  documentId?: string;
  name: string;
  storeNumber?: string | null;
  address?: string | null;
  city?: string | null;
  zip?: string | null;
  latitude?: number | null;
  longitude?: number | null;
  priority?: Priority | null;
  banner?: Banner | null;
  territory?: Territory | null;
}

export interface RouteStop {
  id: number;
  notes?: string | null;
  store?: Store | null;
}

export type Weekday =
  | "monday"
  | "tuesday"
  | "wednesday"
  | "thursday"
  | "friday"
  | "saturday"
  | "sunday";

export type Route = {
  id: number;
  documentId?: string;
  name?: string;
  active?: boolean;
} & Partial<Record<Weekday, RouteStop[]>>;

// ---- Tasks (dynamic-zone components) ----
export type TaskComponentType =
  | "tasks.questionnaire-task"
  | "tasks.action-task"
  | "tasks.photo-task"
  | "tasks.count-task"
  | "tasks.note-task";

export type AnswerType =
  | "boolean"
  | "number"
  | "text"
  | "long_text"
  | "single_select"
  | "multi_select"
  | "photo"
  | "video"
  | "price"
  | "date"
  | "time"
  | "datetime"
  | "percent";

export interface AnswerOption {
  id: number;
  title?: string;
}

export interface ShowCondition {
  questionKey: string;
  operator: "eq" | "neq";
  value: string;
}

export interface QuestionNode {
  id: number;
  title?: string;
  key?: string;
  helpText?: string | null;
  required?: boolean;
  answerType?: AnswerType;
  answerOptions?: AnswerOption[];
  answerOptionsMultiselect?: AnswerOption[];
  showIf?: ShowCondition | null;
  askOncePerCampaign?: boolean;
  skipCondition?: "answered" | "answered_yes" | "answered_no";
}

export interface BaseTask {
  id: number;
  __component: TaskComponentType;
  priority?: Priority;
  estimatedMinutes?: number;
  instructions?: unknown; // Strapi blocks
  target?: string;
}

export interface QuestionnaireTask extends BaseTask {
  __component: "tasks.questionnaire-task";
  name?: string;
  questions?: QuestionNode[];
  repeatPerUpc?: boolean;
  upcs?: { id: number; code: string; name?: string }[];
}
export interface ActionTask extends BaseTask {
  __component: "tasks.action-task";
  title?: string;
  actionType?: string;
  requiresPhoto?: boolean;
}
export interface PhotoTask extends BaseTask {
  __component: "tasks.photo-task";
  title?: string;
  requiredPhotoCount?: number;
  photoType?: string;
  requireGps?: boolean;
  aiAnalysisEnabled?: boolean;
}
export interface CountTask extends BaseTask {
  __component: "tasks.count-task";
  title?: string;
  countType?: string;
}
export interface NoteTask extends BaseTask {
  __component: "tasks.note-task";
  title?: string;
}

export type AnyTask =
  | QuestionnaireTask
  | ActionTask
  | PhotoTask
  | CountTask
  | NoteTask;

export interface Tag {
  id: number;
  documentId?: string;
  name?: string;
  color?: string;
}

export interface StoreSegment {
  id: number;
  documentId?: string;
  name?: string;
  segmentType?: "dynamic" | "static";
  tags?: Tag[];
  storeNumbers?: string[];
  storeUpcMap?: Record<string, string[]> | null;
}

export interface UpcRef {
  code: string;
  name?: string;
}

export interface Campaign {
  id: number;
  documentId?: string;
  name?: string;
  code?: string;
  status?: string;
  priority?: Priority;
  target?: string;
  markets?: { id: number }[];
  regions?: Region[];
  territories?: Territory[];
  retailers?: Retailer[];
  banners?: Banner[];
  stores?: Store[];
  storeSegments?: StoreSegment[];
  taskDefinitions?: AnyTask[];
}

export type VisitStatus = "pending" | "in_progress" | "completed";
export type TaskResponseStatus = "pending" | "completed" | "skipped";

export interface StoreVisit {
  id: number;
  documentId?: string;
  date?: string;
  status?: VisitStatus;
  source?: "route" | "campaign";
}

/** A task instance resolved for a store, with its source + a stable key. */
export interface ResolvedTask {
  task: AnyTask;
  /** unique key = `${sourceType}:${sourceId}:${task.__component}:${task.id}[:upc:${code}]` */
  uid: string;
  sourceType: "campaign";
  sourceId: number;
  sourceName: string;
  /** Set when this task was expanded per-UPC from a repeatPerUpc questionnaire. */
  upc?: UpcRef;
}

export function taskTitle(task: AnyTask): string {
  if (task.__component === "tasks.questionnaire-task") return task.name || "Questionnaire";
  return (task as { title?: string }).title || "Task";
}

export function taskTypeLabel(task: AnyTask): string {
  switch (task.__component) {
    case "tasks.questionnaire-task":
      return "questionnaire";
    case "tasks.action-task":
      return "action";
    case "tasks.photo-task":
      return "photo";
    case "tasks.count-task":
      return "count";
    case "tasks.note-task":
      return "note";
  }
}
