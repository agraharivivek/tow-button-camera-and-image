/**
 * Geolocation abstraction. Web implementation uses navigator.geolocation.
 * Later, swap for @capacitor/geolocation without touching callers (GPS-required
 * photo tasks).
 */

export interface Coords {
  latitude: number;
  longitude: number;
  accuracy?: number;
}

export async function getCurrentPosition(): Promise<Coords | null> {
  if (typeof navigator === "undefined" || !navigator.geolocation) return null;
  return new Promise((resolve) => {
    navigator.geolocation.getCurrentPosition(
      (pos) =>
        resolve({
          latitude: pos.coords.latitude,
          longitude: pos.coords.longitude,
          accuracy: pos.coords.accuracy,
        }),
      () => resolve(null),
      { enableHighAccuracy: true, timeout: 8000 }
    );
  });
}
