import { z } from "zod";

/** Shape of the Strapi users-permissions user from /api/users/me?populate=role,territory */
export const userInfoSchema = z.object({
  id: z.number(),
  documentId: z.string().optional(),
  username: z.string(),
  email: z.string().email(),
  fullName: z.string().nullable().optional(),
  role: z
    .object({
      id: z.number().optional(),
      name: z.string().optional(),
      type: z.string().optional(),
    })
    .nullable()
    .optional(),
  territory: z
    .object({
      id: z.number(),
      documentId: z.string().optional(),
      name: z.string().optional(),
    })
    .nullable()
    .optional(),
});

export type UserInfo = z.infer<typeof userInfoSchema> & { photoUrl?: string };
